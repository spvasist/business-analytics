package com.ecommerce.cartmanagement.beans;

import lombok.Getter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Cart {
    List<Product> cartItems = new ArrayList<>();
    @Getter
    CartStatus cartStatus;
    @Getter
    float cartValue;
    @Getter
    int itemCount;
    @Getter
    Date timeOfCreation;

    public Cart(CartStatus status) {
        this.cartStatus = status;
    }

    public void addProduct(Product item) {
        if (item == null) {
            return;
        }
        cartItems.add(item);
        cartValue += item.price;
        itemCount++;
    }

    public boolean isCategoryPresent(Categories category) {
        return cartItems.stream().anyMatch(item -> item.category.equals(category));
    }

    public boolean isProductPresent(Product product) {
        return cartItems.stream().anyMatch(item -> item.getId() == product.getId());
    }

}
