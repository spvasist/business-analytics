package com.ecommerce.cartmanagement.beans;

import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
public class CartCollection {
    List<Cart> carts = new ArrayList<>();

    public int count() {
        return carts.size();
    }

    public List<Cart> toList(){
        return new ArrayList<>(carts);
    }

    public void sortByItemCount() {
        carts = carts.stream().sorted(Comparator.comparingInt(Cart::getItemCount))
                .collect(Collectors.toList());
    }

    public void sortByCartValue() {
        carts = carts.stream().sorted(Comparator.comparingDouble(Cart::getCartValue))
                .collect(Collectors.toList());
    }

    public CartCollection filterByTimeRange(Date start, Date end) {
        return new CartCollection(
                carts.stream().filter(item ->
                        item.timeOfCreation.after(start) && item.timeOfCreation.before(end))
                        .collect(Collectors.toList()));
    }
}
