package com.ecommerce.cartmanagement.beans;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CartManager {
    List<Cart> carts = new ArrayList<>();

    public void addCart(Cart cart) {
        if (cart == null) {
            return;
        }
        carts.add(cart);
    }

    /**
     * API 1
     *
     * @param cartStatus
     * @return
     */
    public CartCollection getCartsByStatus(CartStatus cartStatus) {
        return new CartCollection(
                carts.stream().filter(item -> item.cartStatus.equals(cartStatus)).collect(Collectors.toList()));
    }

    public CategoryDistribution getCartStatusDistributionByCategory(Categories category) {
        int active = 0, ordered = 0, discarded = 0;
        for (Cart cart : carts) {
            if (cart.isCategoryPresent(category)) {
                switch (cart.cartStatus) {
                    case ACTIVE:
                        active++;
                        break;
                    case ORDERED:
                        ordered++;
                        break;
                    case DISCARDED:
                        discarded++;
                }
            }
        }
        return new CategoryDistribution(active, ordered, discarded);
    }

    public CategoryDistribution getCartStatusDistributionByProduct(Product product) {
        int active = 0, ordered = 0, discarded = 0;
        for (Cart cart : carts) {
            if (cart.isProductPresent(product)) {
                switch (cart.cartStatus) {
                    case ACTIVE:
                        active++;
                        break;
                    case ORDERED:
                        ordered++;
                        break;
                    case DISCARDED:
                        discarded++;
                }
            }
        }
        return new CategoryDistribution(active, ordered, discarded);
    }
}
