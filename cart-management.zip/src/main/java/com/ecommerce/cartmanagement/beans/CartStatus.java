package com.ecommerce.cartmanagement.beans;

public enum CartStatus {
    ACTIVE,
    ORDERED,
    DISCARDED
}
