package com.ecommerce.cartmanagement.beans;

public enum Categories {
    CLOTHING,
    ELECTRONICS
}
