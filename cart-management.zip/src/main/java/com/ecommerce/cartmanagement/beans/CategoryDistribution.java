package com.ecommerce.cartmanagement.beans;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CategoryDistribution {
    int active;
    int ordered;
    int discarded;
}
