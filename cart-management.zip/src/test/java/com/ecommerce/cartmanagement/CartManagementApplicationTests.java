package com.ecommerce.cartmanagement;

import com.ecommerce.cartmanagement.beans.Cart;
import com.ecommerce.cartmanagement.beans.CartCollection;
import com.ecommerce.cartmanagement.beans.CartManager;
import com.ecommerce.cartmanagement.beans.CartStatus;
import com.ecommerce.cartmanagement.beans.Categories;
import com.ecommerce.cartmanagement.beans.Product;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.lang.reflect.Array;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CartManagementApplicationTests {

    @Test
    public void contextLoads() {
    }
    @Test
    public void getCartsByStatus(){
        CartManager manager = prepare();

        Assert.assertEquals(1,manager.getCartsByStatus(CartStatus.ACTIVE).count());
        Assert.assertEquals(1,manager.getCartsByStatus(CartStatus.ORDERED).count());
        Assert.assertEquals(1,manager.getCartsByStatus(CartStatus.DISCARDED).count());

    }

    @Test
    public void testSorting(){

        CartManager manager = prepare();
        CartCollection carts = manager.getCartsByStatus(CartStatus.ORDERED);
        carts.sortByItemCount();
        Assert.assertArrayEquals(carts.toList().toArray(),new Array[]{new Product()});


    }

    private CartManager prepare(){
        CartManager manager = new CartManager();
        Product p1 = new Product(1,"item-1", Categories.CLOTHING,100);
        Product p2 = new Product(2,"item-2", Categories.CLOTHING,200);
        Product p3 = new Product(3,"item-3", Categories.ELECTRONICS,300);
        Product p4 = new Product(4,"item-4", Categories.ELECTRONICS,400);

        Cart cart1 = new Cart(CartStatus.ACTIVE);
        cart1.addProduct(p1);
        cart1.addProduct(p3);

        Cart cart2 = new Cart(CartStatus.ORDERED);
        cart2.addProduct(p1);
        cart2.addProduct(p2);
        cart2.addProduct(p3);
        cart2.addProduct(p4);

        Cart cart3 = new Cart(CartStatus.DISCARDED);
        cart3.addProduct(p1);
        cart3.addProduct(p2);

        manager.addCart(cart1);
        manager.addCart(cart2);
        manager.addCart(cart3);
        return manager;
    }

}
